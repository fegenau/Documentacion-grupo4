# Sign-Bridge v2 - Guía de Instalación y Ejecución

## 📋 Descripción
Sign-Bridge es una aplicación móvil desarrollada con React Native y Expo que permite la detección de lenguaje de señas chileno en tiempo real utilizando la cámara del dispositivo.

---

## 🔧 Requisitos Previos

Antes de comenzar, asegúrate de tener instalado lo siguiente en tu computador:

### 1. Node.js y npm
- **Node.js versión 18.x o superior** (se recomienda la versión LTS)
- Descarga desde: https://nodejs.org/
- Para verificar la instalación, abre una terminal y ejecuta:
  ```bash
  node --version
  npm --version
  ```

### 2. Git (opcional, solo si vas a clonar el repositorio)
- Descarga desde: https://git-scm.com/

### 3. Expo CLI
- Se instalará automáticamente con el proyecto, pero también puedes instalarlo globalmente:
  ```bash
  npm install -g expo-cli
  ```

### 4. Aplicación Expo Go en tu dispositivo móvil
- **Android**: Descarga desde Google Play Store
- **iOS**: Descarga desde App Store
- Busca "Expo Go" en tu tienda de aplicaciones

### 5. (Opcional) Android Studio o Xcode
- **Para Android**: Android Studio con un emulador configurado
- **Para iOS**: Xcode (solo en macOS) con simulador iOS

---

## 📦 Instalación del Proyecto

### Opción A: Desde el archivo ZIP

1. **Descomprime el archivo**
   - Extrae el contenido de `sign-bridge-v2-release.zip` en la carpeta de tu preferencia
   - Ejemplo: `C:\Proyectos\sign-bridge`

2. **Abre una terminal en la carpeta del proyecto**
   - **Windows**: Click derecho en la carpeta → "Abrir en Terminal" o "Abrir ventana de PowerShell aquí"
   - **macOS/Linux**: Click derecho → "Abrir en Terminal"
   - O navega manualmente:
     ```bash
     cd ruta/a/la/carpeta/descomprimida
     ```

3. **Instala las dependencias**
   ```bash
   npm install
   ```
   - Este proceso puede tomar varios minutos
   - Descargará todas las librerías necesarias del proyecto

### Opción B: Desde el repositorio Git (si aplica)

1. **Clona el repositorio**
   ```bash
   git clone https://github.com/fegenau/capstone-sign-bridge.git
   cd capstone-sign-bridge/v2/sing-bridge
   ```

2. **Instala las dependencias**
   ```bash
   npm install
   ```

---

## 🚀 Ejecución del Proyecto

### Método 1: En tu dispositivo físico con Expo Go (RECOMENDADO para primera vez)

1. **Inicia el servidor de desarrollo**
   ```bash
   npm start
   ```
   O también:
   ```bash
   npx expo start
   ```

2. **Aparecerá un código QR en la terminal**
   - Mantén la terminal abierta

3. **Escanea el código QR con tu dispositivo móvil**
   - **Android**: Abre la app Expo Go → Toca "Scan QR code" → Escanea el código
   - **iOS**: Abre la app de Cámara nativa → Apunta al QR → Toca la notificación que aparece

4. **Espera a que la aplicación se cargue**
   - La primera vez puede tomar 1-2 minutos
   - Verás un indicador de progreso en la app Expo Go

5. **La aplicación se abrirá automáticamente**
   - Deberás otorgar permisos de cámara cuando se solicite

### Método 2: En un emulador/simulador Android

1. **Asegúrate de tener Android Studio instalado y un emulador configurado**

2. **Inicia el emulador de Android**
   - Abre Android Studio → AVD Manager → Inicia un dispositivo virtual

3. **Ejecuta el proyecto**
   ```bash
   npm run android
   ```
   O:
   ```bash
   npx expo run:android
   ```

4. **La aplicación se compilará e instalará automáticamente**
   - Este proceso puede tomar varios minutos la primera vez

### Método 3: En un simulador iOS (solo macOS)

1. **Asegúrate de tener Xcode instalado**

2. **Ejecuta el proyecto**
   ```bash
   npm run ios
   ```
   O:
   ```bash
   npx expo run:ios
   ```

3. **Se abrirá el simulador y se instalará la app**

---

## 🎯 Uso de la Aplicación

### Pantalla Principal
1. Al abrir la app, verás la pantalla de bienvenida con el título "Bienvenido a Sing-Bridge"
2. Toca el botón **"Abrir cámara"** para comenzar

### Pantalla de Detección
1. La cámara se activará automáticamente
2. Apunta la cámara hacia señas del lenguaje de señas chileno
3. La aplicación detectará y mostrará las letras en tiempo real
4. El modelo de detección procesará las imágenes y mostrará los resultados

### Permisos
- La primera vez que uses la cámara, el sistema te pedirá permiso
- **Debes aceptar** para que la funcionalidad principal funcione correctamente

---

## 📱 Comandos Disponibles

```bash
# Iniciar el servidor de desarrollo
npm start

# Ejecutar en Android
npm run android

# Ejecutar en iOS
npm run ios

# Ejecutar en navegador web (funcionalidad limitada)
npm run web
```

---

## 🔍 Solución de Problemas Comunes

### Error: "command not found: expo" o "npm not found"
**Solución**: Node.js no está instalado o no está en el PATH del sistema
- Reinstala Node.js desde nodejs.org
- Reinicia la terminal después de instalar

### Error: "Unable to resolve module"
**Solución**: Las dependencias no se instalaron correctamente
```bash
# Elimina node_modules y reinstala
rm -rf node_modules
npm install
```

### Error: "Metro bundler has encountered an error"
**Solución**: Limpia el caché de Metro
```bash
npx expo start --clear
```

### La aplicación no se conecta al servidor de desarrollo
**Solución**: 
- Asegúrate de que tu dispositivo móvil y tu computadora estén en la misma red WiFi
- Desactiva VPNs o firewalls que puedan bloquear la conexión
- Intenta usar el modo túnel:
  ```bash
  npx expo start --tunnel
  ```

### Error de permisos de cámara en el dispositivo
**Solución**:
- Ve a Configuración del dispositivo → Aplicaciones → Expo Go → Permisos
- Activa el permiso de Cámara

### El código QR no aparece o está cortado
**Solución**:
- Amplía la ventana de la terminal
- O usa la versión web del Metro bundler:
  - Presiona `w` en la terminal después de ejecutar `npm start`
  - Se abrirá una página web con el QR más grande

---

## 📂 Estructura del Proyecto

```
sing-bridge/
├── App.tsx                          # Componente principal con navegación
├── CameraScreen.tsx                 # (Si existe) Pantalla de cámara
├── DetectLettersScreen.tsx          # Pantalla de detección de señas
├── index.ts                         # Punto de entrada de la aplicación
├── package.json                     # Dependencias y scripts
├── app.json                         # Configuración de Expo
├── tsconfig.json                    # Configuración de TypeScript
├── eas.json                         # Configuración de EAS Build
├── assets/                          # Recursos estáticos
│   ├── model/                       # Modelo de ML para detección
│   ├── icon.png                     # Ícono de la app
│   ├── splash-icon.png              # Pantalla de inicio
│   └── ...
└── types/                           # Definiciones de tipos TypeScript
    └── react-native-tensorflow.d.ts # Tipos para TensorFlow
```

---

## 🛠️ Tecnologías Utilizadas

- **React Native 0.81.4**: Framework principal
- **Expo ~54.0**: Plataforma de desarrollo
- **TypeScript ~5.9**: Tipado estático
- **React Navigation**: Navegación entre pantallas
- **Expo Camera**: Acceso a la cámara del dispositivo
- **TensorFlow Lite**: Detección de lenguaje de señas

---

## 📝 Notas Adicionales

### Desarrollo
- El servidor de desarrollo se recarga automáticamente cuando guardas cambios
- Presiona `r` en la terminal para recargar manualmente la app
- Presiona `m` para abrir el menú de desarrollo en el dispositivo

### Rendimiento
- La detección en tiempo real puede ser más lenta en dispositivos antiguos
- Se recomienda un dispositivo con al menos 2GB de RAM

### Conectividad
- **Red local (LAN)**: Más rápida, requiere misma WiFi
- **Túnel**: Más lenta pero funciona en cualquier red

---

## 👥 Información del Proyecto

- **Nombre**: Sign-Bridge
- **Versión**: 2.0.0
- **Autor**: fegenau
- **Proyecto**: Capstone
- **Bundle ID**: com.fegenau.singbridge

---

## 📞 Soporte

Si encuentras algún problema durante la instalación o ejecución:

1. Verifica que todos los requisitos previos estén instalados
2. Asegúrate de estar usando las versiones correctas de Node.js y npm
3. Revisa la sección de solución de problemas
4. Consulta la documentación oficial de Expo: https://docs.expo.dev/

---

## ✅ Checklist de Instalación

Usa este checklist para asegurarte de seguir todos los pasos:

- [ ] Node.js 18.x o superior instalado
- [ ] npm instalado y funcionando
- [ ] Expo Go descargado en el dispositivo móvil
- [ ] Proyecto descomprimido o clonado
- [ ] `npm install` ejecutado exitosamente
- [ ] `npm start` ejecutado sin errores
- [ ] Código QR escaneado con Expo Go
- [ ] App cargada en el dispositivo
- [ ] Permisos de cámara otorgados
- [ ] Aplicación funcionando correctamente

---

**¡Listo! Ahora puedes usar Sign-Bridge para detectar lenguaje de señas chileno en tiempo real. 🎉**
