declare module 'react-native-tensorflow' {
  export const TensorflowLite: any;
}
